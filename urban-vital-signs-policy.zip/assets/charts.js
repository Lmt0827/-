(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: Policy Trend ---
  var elTrend = document.getElementById('chart-trend');
  var chartTrend = null;
  if (elTrend) {
    chartTrend = echarts.init(elTrend, null, { renderer: 'svg' });
    chartTrend.setOption({
      animation: false,
      tooltip: { trigger: 'axis', appendToBody: true, backgroundColor: bg2, borderColor: rule, textStyle: { color: ink } },
      legend: { data: ['国内政策/标准', '国外政策/标准'], textStyle: { color: muted }, bottom: 0 },
      grid: { left: '3%', right: '4%', bottom: '12%', top: '10%', containLabel: true },
      xAxis: {
        type: 'category',
        data: ['1月', '2月', '3月', '4月', '5月', '6月'],
        axisLine: { lineStyle: { color: rule } },
        axisLabel: { color: muted }
      },
      yAxis: {
        type: 'value',
        axisLine: { lineStyle: { color: rule } },
        axisLabel: { color: muted },
        splitLine: { lineStyle: { color: rule, opacity: 0.3 } }
      },
      series: [
        {
          name: '国内政策/标准',
          type: 'line',
          data: [2, 3, 1, 4, 5, 6],
          smooth: true,
          lineStyle: { color: accent, width: 3 },
          itemStyle: { color: accent },
          areaStyle: { color: accent + '22' }
        },
        {
          name: '国外政策/标准',
          type: 'line',
          data: [1, 2, 3, 2, 4, 3],
          smooth: true,
          lineStyle: { color: accent2, width: 3 },
          itemStyle: { color: accent2 },
          areaStyle: { color: accent2 + '22' }
        }
      ]
    });
    window.addEventListener('resize', function() { chartTrend.resize(); });
  }

  // --- Chart: Domestic Policy Type Pie ---
  var elPieDom = document.getElementById('chart-pie-domestic');
  var chartPieDom = null;
  if (elPieDom) {
    chartPieDom = echarts.init(elPieDom, null, { renderer: 'svg' });
    chartPieDom.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true, backgroundColor: bg2, borderColor: rule, textStyle: { color: ink } },
      legend: { orient: 'vertical', left: 'left', textStyle: { color: muted } },
      series: [
        {
          name: '政策类型',
          type: 'pie',
          radius: ['40%', '70%'],
          center: ['60%', '50%'],
          itemStyle: { borderRadius: 6, borderColor: bg2, borderWidth: 2 },
          label: { color: ink },
          data: [
            { value: 5, name: '国家层面政策', itemStyle: { color: accent } },
            { value: 4, name: '地方层面政策', itemStyle: { color: '#34d399' } },
            { value: 3, name: '国家标准/行业标准', itemStyle: { color: '#fbbf24' } },
            { value: 2, name: '地方标准', itemStyle: { color: '#f472b6' } }
          ]
        }
      ]
    });
    window.addEventListener('resize', function() { chartPieDom.resize(); });
  }

  // --- Chart: International Region Pie ---
  var elPieIntl = document.getElementById('chart-pie-intl');
  var chartPieIntl = null;
  if (elPieIntl) {
    chartPieIntl = echarts.init(elPieIntl, null, { renderer: 'svg' });
    chartPieIntl.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true, backgroundColor: bg2, borderColor: rule, textStyle: { color: ink } },
      legend: { orient: 'vertical', left: 'left', textStyle: { color: muted } },
      series: [
        {
          name: '地区分布',
          type: 'pie',
          radius: ['40%', '70%'],
          center: ['60%', '50%'],
          itemStyle: { borderRadius: 6, borderColor: bg2, borderWidth: 2 },
          label: { color: ink },
          data: [
            { value: 4, name: '欧盟', itemStyle: { color: '#3b82f6' } },
            { value: 3, name: 'ISO国际标准', itemStyle: { color: '#8b5cf6' } },
            { value: 2, name: '美国', itemStyle: { color: '#ef4444' } },
            { value: 2, name: '英国', itemStyle: { color: '#10b981' } },
            { value: 2, name: '新加坡', itemStyle: { color: '#f59e0b' } },
            { value: 1, name: '日本', itemStyle: { color: '#ec4899' } },
            { value: 1, name: '联合国/ITU', itemStyle: { color: '#06b6d4' } }
          ]
        }
      ]
    });
    window.addEventListener('resize', function() { chartPieIntl.resize(); });
  }

  // --- Chart: Radar Comparison ---
  var elRadar = document.getElementById('chart-radar');
  var chartRadar = null;
  if (elRadar) {
    chartRadar = echarts.init(elRadar, null, { renderer: 'svg' });
    chartRadar.setOption({
      animation: false,
      tooltip: { trigger: 'item', appendToBody: true, backgroundColor: bg2, borderColor: rule, textStyle: { color: ink } },
      legend: { data: ['国内重点', '国外重点'], textStyle: { color: muted }, bottom: 0 },
      radar: {
        indicator: [
          { name: 'CIM/数字孪生', max: 100 },
          { name: '城市生命线', max: 100 },
          { name: 'AI智能应用', max: 100 },
          { name: '数据共享互通', max: 100 },
          { name: '标准体系建设', max: 100 },
          { name: '风险评估预警', max: 100 },
          { name: '物联网感知', max: 100 },
          { name: '城市体检更新', max: 100 }
        ],
        axisName: { color: muted },
        splitArea: { areaStyle: { color: [bg2, 'transparent'] } },
        axisLine: { lineStyle: { color: rule } },
        splitLine: { lineStyle: { color: rule } }
      },
      series: [
        {
          name: '热点对比',
          type: 'radar',
          data: [
            {
              value: [95, 90, 70, 85, 95, 80, 85, 95],
              name: '国内重点',
              lineStyle: { color: accent, width: 2 },
              itemStyle: { color: accent },
              areaStyle: { color: accent + '33' }
            },
            {
              value: [90, 60, 95, 80, 85, 70, 90, 50],
              name: '国外重点',
              lineStyle: { color: accent2, width: 2 },
              itemStyle: { color: accent2 },
              areaStyle: { color: accent2 + '33' }
            }
          ]
        }
      ]
    });
    window.addEventListener('resize', function() { chartRadar.resize(); });
  }

  // 暴露resize函数供标签切换调用
  window._resizeCharts = function() {
    if (chartTrend) chartTrend.resize();
    if (chartPieDom) chartPieDom.resize();
    if (chartPieIntl) chartPieIntl.resize();
    if (chartRadar) chartRadar.resize();
  };
})();
